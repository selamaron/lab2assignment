package prog2B;

public class OrderLine {

}
